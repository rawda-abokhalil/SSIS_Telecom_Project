CREATE DATABASE TelecomDB;
GO
USE TelecomDB;

CREATE TABLE Telecom_Transactions (
  Transaction_id INT,
  IMSI VARCHAR(20),
  subscriber_id INT,
  TAC VARCHAR(10),
  SNR VARCHAR(10),
  IMEI VARCHAR(20),
  CELL INT,
  LAC INT,
  EVENT_TYPE VARCHAR(5),
  EVENT_TS DATETIME
);

CREATE TABLE Rejected_Records (
  Transaction_id INT,
  IMSI VARCHAR(20),
  IMEI VARCHAR(20),
  CELL INT,
  LAC INT,
  EVENT_TYPE VARCHAR(5),
  EVENT_TS VARCHAR(50),
  FileName VARCHAR(100)
);
